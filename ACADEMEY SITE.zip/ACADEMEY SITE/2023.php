<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_race'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $athlete = $_POST['athlete'];
   $distance = $_POST['distance'];
   $time = $_POST['time'];
   $dob = $_POST['dob'];
   $date = $_POST['date'];
   

   $select_race_name = mysqli_query($conn, "SELECT name FROM `2023_road_races` WHERE name = '$name'") or die('query failed');

   if(mysqli_num_rows($select_race_name) > 0){
      $message[] = 'race already added';
   }else{
      $add_race_query = mysqli_query($conn, "INSERT INTO `2023_road_races`(name,athlete,distance,time,dob,date) 
      VALUES('$name', '$athlete','$distance','$time','$dob','$date')") or die('query failed');
   }
}

if(isset($_POST['update_race'])){

   $update_p_id = $_POST['update_p_id'];
   $update_name =  $_POST['update_name'];
   $update_athlete = $_POST['update_athlete'];
   $update_distance = $_POST['update_distance'];
   $update_time = $_POST['update_time'];
   $update_dob = $_POST['update_dob'];
   $update_date = $_POST['update_date'];
   
   mysqli_query($conn, "UPDATE `2023_road_races` SET name = '$update_name', athlete = '$update_athlete',
   distance = '$update_distance', time ='$update_time',  dob ='$update_dob', date = '$update_date'
    WHERE id = '$update_p_id'") or die('query failed');
   
   header('location:2023.php');
   
   }

   if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `2023_road_races` WHERE id = '$delete_id'") or die('query failed');
   header('location:2023.php');
}
if(isset($_POST['add_tt'])){

    $month = mysqli_real_escape_string($conn, $_POST['month']);
    $names = $_POST['name'];
    $times = $_POST['time'];
    $dobs = $_POST['dob'];
    
 
    $select_tt_name = mysqli_query($conn, "SELECT month FROM `2023_time_trial` WHERE month = '$month'") or die('query failed');
 
    if(mysqli_num_rows($select_tt_name) > 0){
       $message[] = 'month already added';
    }else{
       $add_tt_query = mysqli_query($conn, "INSERT INTO `2023_time_trial`(month,name,time,dob) 
       VALUES('$month', '$names','$times','$dobs')") or die('query failed');
    }
 }
 
 if(isset($_POST['update_tt'])){
 
    $update_t_id = $_POST['update_t_id'];
    $update_month =  $_POST['update_month'];
    $update_names = $_POST['update_name'];
    $update_time = $_POST['update_time'];
    $update_dob = $_POST['update_dob'];
    
    mysqli_query($conn, "UPDATE `2023_time_trial` SET month = '$update_month', name = '$update_names',
    time ='$update_times',  dob ='$update_dobs'
     WHERE id = '$update_t_id'") or die('query failed');
    
    header('location:2023.php');
    
    }
 
    if(isset($_GET['delete'])){
    $delete_t_id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM `2023_time_trial` WHERE id = '$delete_t_id'") or die('query failed');
    header('location:2023.php');
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Athletes</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'history_header.php'; ?>

<!-- athlete CRUD section starts  -->

<section class="add-athletes">

   <h1 class="title">Road Races</h1>

   <form action="" method="post" enctype="multipart/form-data">
      <h3>add race</h3>
      <input type="text" name="name" class="box" placeholder="enter road race name" required>
      <input type="text" min="0" name="athlete" class="box" placeholder="enter athlete name" required>
      <input type="text" min="0" name="distance" class="box" placeholder="enter race distance" required>
      <input type="text" min="0" name="time" class="box" placeholder="enter athlete time" required>
      <input type="date" min="0" name="dob" class="box" placeholder="enter athlete date of birth" required>
      <input type="date" min="0" name="date" class="box" placeholder="enter race date" required>
      <input type="submit" value="add race" name="add_race" class="btn">
   </form>

   <h1 class="title">Time Trials</h1>

<form action="" method="post" enctype="multipart/form-data">
   <h3>add time trial</h3>
   <input type="text" name="month" class="box" placeholder="enter month name" required>
   <input type="text" min="0" name="name" class="box" placeholder="enter athlete name" required>
   <input type="text" min="0" name="time" class="box" placeholder="enter time ran" required>
   <input type="date" min="0" name="dob" class="box" placeholder="enter athlete date of birth" required>
   <input type="submit" value="add time trial" name="add_tt" class="btn">
</form>
</section>

<!-- athlete CRUD section ends -->

<!-- show athlete  -->

<section class="show-athletes">

   <div class="box-container">

      <?php
         $select_races = mysqli_query($conn, "SELECT * FROM `2023_road_races`") or die('query failed');
         if(mysqli_num_rows($select_races) > 0){
            while($fetch_races = mysqli_fetch_assoc($select_races)){
      ?>
      <div class="box">
         <div class="name">Race name:   <?php echo $fetch_races['name']; ?></div>
         <div class="time">Athlete name:    <?php echo $fetch_races['athlete']; ?></div>
         <div class="time">Distance:    <?php echo $fetch_races['distance']; ?></div>
         <div class="time">Time:  <?php echo $fetch_races['time']; ?></div>
         <div class="time">Athlete date of birth:   <?php echo $fetch_races['dob']; ?></div>
         <div class="time">Race date:   <?php echo $fetch_races['date']; ?></div>
         <a href="2023.php?update=<?php echo $fetch_races['id']; ?>" class="option-btn">update</a>
         <a href="2023.php?delete=<?php echo $fetch_races['id']; ?>" class="delete-btn" onclick="return confirm('delete this race?');">delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no races added yet!</p>';
      }
      ?>
      <?php
      $select_tt = mysqli_query($conn, "SELECT * FROM `2023_time_trial`") or die('query failed');
      if(mysqli_num_rows($select_tt) > 0){
         while($fetch_tt = mysqli_fetch_assoc($select_tt)){
   ?>
   <div class="box">
      <div class="name">Month:   <?php echo $fetch_tt['month']; ?></div>
      <div class="time">Name:    <?php echo $fetch_tt['name']; ?></div>
      <div class="time">Time:  <?php echo $fetch_tt['time']; ?></div>
      <div class="time">Athlete date of birth:   <?php echo $fetch_tt['dob']; ?></div>
      <a href="2023.php?update=<?php echo $fetch_tt['id']; ?>" class="option-btn">update</a>
      <a href="2023.php?delete=<?php echo $fetch_tt['id']; ?>" class="delete-btn" onclick="return confirm('delete this month?');">delete</a>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">no monthly time trial added yet!</p>';
   }
   ?>
   </div>

</section>

<section class="edit-athletes-form">

   <?php
      if(isset($_GET['update'])){
               $update_id = $_GET['update'];
               $update_query = mysqli_query($conn, "SELECT * FROM `2023_road_races` WHERE id = '$update_id'") or die('query failed');
               if(mysqli_num_rows($update_query) > 0){
                  while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
      <form action="" method="post" enctype="multipart/form-data">
         <input type="text" name="update_name" value="<?php echo $fetch_update['name'];?>" class="box" required placeholder="enter road race name">
         <input type="text" name="update_athlete" value="<?php echo $fetch_update['athlete'];?>" min="0" class="box" required placeholder="enter athlete name">
         <input type="text" name="update_distance" value="<?php echo $fetch_update['distance'];?>" min="0" class="box" required placeholder="enter athlete distance">
         <input type="text" name="update_time" value="<?php echo $fetch_update['time'];?>" min="0" class="box" required placeholder="enter athlete race time">
         <input type="date" name="update_dob" value="<?php echo $fetch_update['dob'];?>" min="0" class="box" required placeholder="enter athlete date of birth">
         <input type="date" name="update_date" value="<?php echo $fetch_update['date'];?>" min="0" class="box" required placeholder="enter road race date">
         <input type="submit" value="update" name="update_race" class="btn">
         <input type="reset" value="cancel" id="close-update" class="option-btn">
      </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-athletes-form").style.display = "none";</script>';
      }
   ?>
   <?php
      if(isset($_GET['update'])){
               $update_t_id = $_GET['update'];
               $update_query = mysqli_query($conn, "SELECT * FROM `2023_time_trial` WHERE id = '$update_t_id'") or die('query failed');
               if(mysqli_num_rows($update_query) > 0){
                  while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
      <form action="" method="post" enctype="multipart/form-data">
         <input type="text" name="update_month" value="<?php echo $fetch_update['month'];?>" class="box" required placeholder="enter month">
         <input type="text" name="update_name" value="<?php echo $fetch_update['name'];?>" min="0" class="box" required placeholder="enter athlete name">
         <input type="text" name="update_time" value="<?php echo $fetch_update['time'];?>" min="0" class="box" required placeholder="enter athlete race time">
         <input type="date" name="update_dob" value="<?php echo $fetch_update['dob'];?>" min="0" class="box" required placeholder="enter athlete date of birth">
         <input type="submit" value="update" name="update_tt" class="btn">
         <input type="reset" value="cancel" id="close-update" class="option-btn">
      </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-athletes-form").style.display = "none";</script>';
      }
   ?>
</section>




<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>