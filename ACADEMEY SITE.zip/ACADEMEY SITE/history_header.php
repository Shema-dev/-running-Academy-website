<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<header class="header">

   <div class="flex">

      <a href="admin_page.php" class="logo">Admin<span>Panel</span></a>

      <nav class="navbar">
          <a href="2023.php">2023</a>
         <a href="2022.php">2022</a>
         <a href="2021.php">2021</a>
         <a href="2020.php">2020</a>
         <a href="2019.php">2019</a>
         <a href="2018.php">2018</a>
         <a href="2017.php">2017</a>
         <a href="2016.php">2016</a>
         <a href="2015.php">2015</a>
         <a href="2014.php">2014</a>
         <a href="2013.php">2013</a>
      </nav>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
      </div>

      <div class="account-box">
         <p>username : <span><?php echo $_SESSION['admin_name']; ?></span></p>
         <p>email : <span><?php echo $_SESSION['admin_email']; ?></span></p>
         <a href="logout.php" class="delete-btn">logout</a>
         <div>new <a href="login.php">login</a> | <a href="register.php">register</a></div>
      </div>

   </div>

</header>