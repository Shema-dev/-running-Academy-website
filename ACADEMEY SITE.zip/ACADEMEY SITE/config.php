<?php

$conn = mysqli_connect('localhost','root','','academy_db') or die('connection failed');

?>